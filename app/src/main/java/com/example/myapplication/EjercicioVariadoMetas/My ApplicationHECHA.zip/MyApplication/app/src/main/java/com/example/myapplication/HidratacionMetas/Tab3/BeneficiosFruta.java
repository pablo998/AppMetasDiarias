package com.example.myapplication.HidratacionMetas.Tab3;



public class BeneficiosFruta {
    private String beneficio;


    public BeneficiosFruta(String meta) {
        this.beneficio = meta;

    }

    public String getMeta() {
        return beneficio;
    }
}
