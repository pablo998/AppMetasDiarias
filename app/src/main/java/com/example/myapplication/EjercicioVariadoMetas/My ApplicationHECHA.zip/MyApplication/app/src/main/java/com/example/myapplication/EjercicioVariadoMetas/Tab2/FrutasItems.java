package com.example.myapplication.EjercicioVariadoMetas.Tab2;



public class FrutasItems {
    private String meta;


    public FrutasItems(String meta) {
        this.meta = meta;

    }

    public String getMeta() {
        return meta;
    }
}
