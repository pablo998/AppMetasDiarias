package com.example.myapplication.MetasPersonalizadas.Tab3;



public class EjercicioItems {
    private String meta;


    public EjercicioItems(String meta) {
        this.meta = meta;

    }

    public String getMeta() {
        return meta;
    }
}
