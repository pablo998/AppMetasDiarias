package com.example.myapplication.MetasPersonalizadas.Tab2;



public class ComidaItems {
    private String meta;


    public ComidaItems(String meta) {
        this.meta = meta;

    }

    public String getMeta() {
        return meta;
    }
}
