package com.example.myapplication.ComidaDiariaMetas.Tab3;



public class BeneficiosFruta {
    private String beneficio;


    public BeneficiosFruta(String meta) {
        this.beneficio = meta;

    }

    public String getMeta() {
        return beneficio;
    }
}
